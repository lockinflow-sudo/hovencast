package airplay

import (
	"bytes"
	"context"
	"os"
	"os/exec"
	"path/filepath"
	"syscall"
	"testing"
	"time"
)

func TestTransportCaptureRejectsRegularFile(t *testing.T) {
	path := filepath.Join(t.TempDir(), "not-a-pipe")
	if err := os.WriteFile(path, []byte("data"), 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := PrepareTransportCapture(context.Background(), CaptureConfig{}, path); err == nil {
		t.Fatal("accepted regular file")
	}
}

func TestTransportCaptureForwardsH264AndStops(t *testing.T) {
	if _, err := exec.LookPath("ffmpeg"); err != nil {
		t.Skip("ffmpeg unavailable")
	}
	dir := t.TempDir()
	input := filepath.Join(dir, "input.ts")
	fifo := filepath.Join(dir, "capture.ts")
	cmd := exec.Command("ffmpeg", "-v", "error", "-f", "lavfi", "-i", "testsrc2=size=160x90:rate=30", "-t", "1", "-c:v", "libx264", "-preset", "ultrafast", "-tune", "zerolatency", "-f", "mpegts", input)
	if out, err := cmd.CombinedOutput(); err != nil {
		t.Fatalf("fixture: %v %s", err, out)
	}
	data, err := os.ReadFile(input)
	if err != nil {
		t.Fatal(err)
	}
	if err = syscall.Mkfifo(fifo, 0600); err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	preparation, err := PrepareTransportCapture(ctx, CaptureConfig{VideoCodec: VideoCodecH264}, fifo)
	if err != nil {
		t.Fatal(err)
	}
	capture, err := preparation.StartWithCodec(160, 90, VideoCodecH264)
	if err != nil {
		t.Fatal(err)
	}
	defer capture.Stop()
	go func() {
		f, e := os.OpenFile(fifo, os.O_WRONLY, 0)
		if e == nil {
			defer f.Close()
			f.Write(data)
		}
	}()
	buf := make([]byte, 8192)
	n, err := capture.Read(buf)
	if err != nil {
		t.Fatal(err)
	}
	if n == 0 || !bytes.Contains(buf[:n], []byte{0, 0, 0, 1}) {
		t.Fatal("no Annex-B video forwarded")
	}
	capture.Stop()
	select {
	case <-capture.waitCh:
	case <-time.After(3 * time.Second):
		t.Fatal("capture child leaked")
	}
}
