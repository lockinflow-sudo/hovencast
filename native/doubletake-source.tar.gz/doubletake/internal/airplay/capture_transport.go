package airplay

import (
	"context"
	"fmt"
	"os"
	"os/exec"
)

// PrepareTransportCapture reuses HovenCast's selected and encoded screen source.
// It never opens a second portal or captures a different display.
func PrepareTransportCapture(ctx context.Context, cfg CaptureConfig, path string) (*CapturePreparation, error) {
	info, err := os.Stat(path)
	if err != nil {
		return nil, err
	}
	if info.Mode()&os.ModeNamedPipe == 0 {
		return nil, fmt.Errorf("transport input must be a FIFO")
	}
	cfg.TransportInput = path
	cfg.VideoCodec = VideoCodecH264
	return &CapturePreparation{ctx: ctx, cfg: cfg, kind: capturePreparationTransport}, nil
}

func startTransportCapture(ctx context.Context, path string) (*ScreenCapture, error) {
	lifetime, cancel := context.WithCancel(ctx)
	cmd := exec.CommandContext(lifetime, "ffmpeg", "-hide_banner", "-loglevel", "warning", "-probesize", "32768", "-analyzeduration", "0", "-f", "mpegts", "-i", path, "-map", "0:v:0", "-c:v", "copy", "-an", "-f", "h264", "-flush_packets", "1", "pipe:1")
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		cancel()
		return nil, err
	}
	cmd.Stderr = os.Stderr
	if err = cmd.Start(); err != nil {
		cancel()
		stdout.Close()
		return nil, err
	}
	capture := &ScreenCapture{cmd: cmd, stdout: stdout, cancel: cancel, waitCh: make(chan struct{})}
	go func() { capture.waitErr = cmd.Wait(); close(capture.waitCh) }()
	return capture, nil
}
